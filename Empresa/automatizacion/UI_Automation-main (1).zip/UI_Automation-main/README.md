Ui tests for the project.
Using:
- Selene for work with browser
- PyTest as a testing framework
- Allure for pretty reports

Worked for Python3.6 - Python3.9

To download all libraries use pip install -r requirements.txt
