MARKETPLACE = {'dev': "https://market.vatom.cool/",
               'qa': "https://market.vatom.cc/",
               'prod': "https://market.vatom.com/"}
